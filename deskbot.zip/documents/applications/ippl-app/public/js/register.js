function setFormMessage(formElement, tipe, message) {
    const messageElement = formElement.querySelector(".form__message");

    messageElement.textContent = message;
    messageElement.classList.remove("form__message--success", "form__message--error");
    messageElement.classList.add('form__message--'+tipe);
}

function setInputError(inputElement, message){
    inputElement.classList.add("form__input--error");
    inputElement.parentElement.querySelector(".form__input-error-message").textContent = message;
}

function setInputSuccess(inputElement, message){
    inputElement.classList.remove("form__input--error");
    inputElement.classList.add("form__input--success");
    inputElement.parentElement.querySelector(".form__input-error-message").textContent = message;
}

document.addEventListener("DOMContentLoaded", () =>{
    // const loginForm = document.querySelector("#login");
    const CreateAccountForm = document.querySelector("#CreateAccount");

    // document.querySelector("#linkCreateAccount").addEventListener("click", e => {
    //     e.preventDefault();
    //     loginForm.classList.add("form--hidden");
    //     CreateAccountForm.classList.remove("form--hidden");
    // });

    // document.querySelector("#linkLogin").addEventListener("click", e => {
    //     e.preventDefault();
    //     loginForm.classList.remove("form--hidden");
    //     CreateAccountForm.classList.add("form--hidden");
    // });

    // loginForm.addEventListener("submit", e => {
    //     e.preventDefault();
    //     if (document.getElementById("loginUsr").value === document.getElementById("signupUsername")){
    //         setFormMessage(loginForm, "success", "Login Sukses");
    //     } else {
    //         setFormMessage(loginForm, "error", "Username atau Password Salah");
    //     }
    // });

    document.querySelectorAll("#signupUsername").forEach(inputElement => {
        inputElement.addEventListener("blur", e => {
            if (e.target.id === "signupUsername" && e.target.value.length > 0 && e.target.value.length < 6) {
                setInputError(inputElement, "Username harus memiliki minimal 6 digit");
            }
            else if (e.target.id === "signupUsername" && e.target.value.length >= 6) {
                setInputSuccess(inputElement, " ");
            }
        });
    });

    document.querySelectorAll("#signupEmail").forEach(inputElement => {
        inputElement.addEventListener("blur", e => {
            if (e.target.id === "signupEmail" && e.target.value.includes("@") === true && e.target.value.includes(".") === true && e.target.value.length >= 8) {
                setInputSuccess(inputElement, " ");
            }
            else {
                setInputError(inputElement, "Mohon menuliskan alamat Email dengan benar");
            }
        });
    });

    document.querySelectorAll("#signupPasswd").forEach(inputElement => {
        inputElement.addEventListener("blur", e => {
            if (e.target.id === "signupPasswd" && e.target.value.length > 0 && e.target.value.length < 8) {
                setInputError(inputElement, "Password harus memiliki minimal 8 digit");
            }
            else if (e.target.id === "signupPasswd" && e.target.value.length >= 8) {
                setInputSuccess(inputElement, " ");
            }
        });
    });

    document.querySelectorAll("#signupCPasswd").forEach(inputElement => {
        inputElement.addEventListener("blur", e => {
            if (document.getElementById('signupPasswd').value === document.getElementById('signupCPasswd').value) {
                setInputSuccess(inputElement, " ");
            } 
            else {
                setInputError(inputElement, "Password tidak sama");
            }
        });
    });
});