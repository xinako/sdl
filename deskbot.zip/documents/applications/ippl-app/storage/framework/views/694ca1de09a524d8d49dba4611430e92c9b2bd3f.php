

<?php $__env->startSection('content'); ?>
    <div class="container px-6 mx-auto">
        <h3 class="text-2xl font-medium text-gray-700">Product List</h3>
        <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
            
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->kategori == 'Food'): ?>
                    <div class="box">
                        <div class="image">
                            <img src="<?php echo e(url($product->image)); ?>" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3><?php echo e($product->kategori); ?></h3>
                            <p><?php echo e($product->name); ?></p>
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data" class="btn">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($product->kategori); ?>" name="kategori">
                                <input type="hidden" value="<?php echo e($product->name); ?>" name="name">
                                <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                <input type="hidden" value="<?php echo e($product->image); ?>"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.<?php echo e($product->price); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section> 
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
    
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->kategori == 'Fastfood'): ?>
                    <div class="box">
                        <div class="image">
                            <img src="<?php echo e(url($product->image)); ?>" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3><?php echo e($product->kategori); ?></h3>
                            <p><?php echo e($product->name); ?></p>
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data" class="btn">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($product->kategori); ?>" name="kategori">
                                <input type="hidden" value="<?php echo e($product->name); ?>" name="name">
                                <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                <input type="hidden" value="<?php echo e($product->image); ?>"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.<?php echo e($product->price); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section> 
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
    
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->kategori == 'Snack'): ?>
                    <div class="box">
                        <div class="image">
                            <img src="<?php echo e(url($product->image)); ?>" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3><?php echo e($product->kategori); ?></h3>
                            <p><?php echo e($product->name); ?></p>
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data" class="btn">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($product->kategori); ?>" name="kategori">
                                <input type="hidden" value="<?php echo e($product->name); ?>" name="name">
                                <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                <input type="hidden" value="<?php echo e($product->image); ?>"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.<?php echo e($product->price); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section> 
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
    
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->kategori == 'choco'): ?>
                    <div class="box">
                        <div class="image">
                            <img src="<?php echo e(url($product->image)); ?>" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3><?php echo e($product->kategori); ?></h3>
                            <p><?php echo e($product->name); ?></p>
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data" class="btn">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($product->kategori); ?>" name="kategori">
                                <input type="hidden" value="<?php echo e($product->name); ?>" name="name">
                                <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                <input type="hidden" value="<?php echo e($product->image); ?>"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.<?php echo e($product->price); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section> 
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/products.blade.php ENDPATH**/ ?>