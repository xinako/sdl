
<?php $__env->startSection('container'); ?>
<script src="https://apps.elfsight.com/p/platform.js" defer></script>
<center><div class="elfsight-app-17580849-45cf-4e6e-8cba-0ec8f5670087" style="margin-top: 5rem"></div></center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/chat.blade.php ENDPATH**/ ?>