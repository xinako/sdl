
<?php $__env->startSection('container'); ?>

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
        <div class="container">
  
          <div class="d-flex justify-content-between align-items-center">
            <h2>Profile</h2>
            <ol>
              <li><a href="index.html">Home</a></li>
              <li>Test</li>
              
            </ol>
          </div>
  
        </div>
      </section><!-- End Breadcrumbs Section -->
  
      <section class="inner-page">
        <div class="container">
          <p>
            <ul><p class="menuses">Name : <?php echo e(auth()->user()->username); ?></p></ul>
              <ul><p class="menuses">Email : <?php echo e(auth()->user()->email); ?></p></ul>
              <form action="/logout" method="POST">
                <?php echo csrf_field(); ?>
                <ul><button type="submit" class="logoutx">Logout</button></ul>
            </form>
          </p>
        </div>
      </section>
  
    </main><!-- End #main -->

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/login/profile.blade.php ENDPATH**/ ?>