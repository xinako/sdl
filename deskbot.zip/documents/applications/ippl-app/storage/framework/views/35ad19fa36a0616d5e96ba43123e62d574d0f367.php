
<?php $__env->startSection('container'); ?>
<style>
    .home {
        font-size: 1rem;
        font-weight: 400;
        line-height: 1;
        color: #030100;
        text-align: left;
        margin-top: 15%;
        margin-left: 25%;
    }
    .menuses {
        border-radius: 4px;
        box-shadow: 0 3px 6px #0000001c;
        background-color: #fff;
        padding: 15px 15px 11px;
        margin: 10px 16px 10px 0;
        position: relative;
        width: 114px;
        height: 150px;
        display: flex;
        flex-direction: column;
        align-items: center;
        outline: none;
        cursor: pointer;
        color: black;
    }

    .menus {
        display: flex;
        flex-direction: row;
        margin-top: 27px;
    }
</style>
<section class="home">
    <div class="content" style="
    color: black;">
        <div class="menus" style="">
            
            <a class="menuses" href="/checkout"><img src="img/hewani.jpg" alt="Consult Online With Veteriner"width="80" height="80" style="border-radius: 5px;"><p>Drh. Sayekti</p><center>Rp. 20.000</center></a>
        </div> 
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/online.blade.php ENDPATH**/ ?>