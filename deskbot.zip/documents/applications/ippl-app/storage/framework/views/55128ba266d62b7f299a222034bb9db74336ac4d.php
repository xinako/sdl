
<?php $__env->startSection('container'); ?>
<link rel="stylesheet" href="css/main.css">
    <div class="bodih">
        <form class="form" id="CreateAccount" method="POST" action="/register">
            <?php echo csrf_field(); ?>
            <h1 class="form__title">Buat Akun Mitra</h1>
            <div class="form__message form__input--error"></div>

            <div class="form__input-group">
                <input type="text" name="username" id="signupUsername" class="form__input" placeholder="Username" required value="<?php echo e(old('username')); ?>"/>
                <div class="form__input-error-message"></div>
                
            </div>

            <div class="form__input-group">
                <input type="email" name="email" id="signupEmail" class="form__input" placeholder="Email Address" required value="<?php echo e(old('email')); ?>"/>
                <div class="form__input-error-message"></div>
   
            </div>

            <div class="form__input-group">
                <input type="password" name="password" id="signupPasswd" class="form__input" placeholder="Password"  required/>
                <div class="form__input-error-message"></div>
                
            </div>

            <div class="form__input-group">
                <input type="password" name="cpassword" id="signupCPasswd" class="form__input" placeholder="Confirm Password" required/>
                <div class="form__input-error-message"></div>
                <?php $__errorArgs = ['cpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form__input-error-message">Mohon mengisi Form dengan Benar!</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <button class="form__button" type="submit">Daftar</button>
            
            <p class="form__text">
                <a href="/login" id="linkLogin" class="form__link">Sudah punya akun? Sign in disini!</a>
            </p>
        </form>
    </div>
    <script src="js/register.js"></script>
<?php $__env->stopSection(); ?>   

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/register/index2.blade.php ENDPATH**/ ?>