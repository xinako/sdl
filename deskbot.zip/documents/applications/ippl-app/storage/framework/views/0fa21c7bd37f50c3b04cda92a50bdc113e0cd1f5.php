<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/main.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <title><?php echo e($title); ?></title>
</head>
<body>
    
    <div class="container">
        <form class="form" id="login" action="<?php echo e(url('user/create')); ?>" method="POST">
            <h1 class="form__title">Login</h1>
            <div class="form__message form__input--error"></div>
            
            <div class="form__input-group">
                <input type="text" name="loginUsername" id="loginUsr" class="form__input" placeholder="Username or Email" />
                <div class="form__input-error-message"></div>
            </div>
          
            <div class="form__input-group">
                <input type="password" name="loginPasswd" id="loginPass" class="form__input" placeholder="Password"  />
                <div class="form__input-error-message"></div>
            </div>

            <button class="form__button" href="home.xhtml" type="submit">Login</button>
            
            <p class="form__text">
                <a href="#" class="form__link">Lupa Password?</a>
            </p>
            
            <p class="form__text">
                <a href="#" id="linkCreateAccount" class="form__link">Tidak punya akun? Buat akun disini!</a>
            </p>
        </form>

        <form class="form form--hidden" id="CreateAccount" method="POST" action="<?php echo e(url('user/create')); ?>">
            <h1 class="form__title">Create Account</h1>
            <div class="form__message form__input--error"></div>

            <div class="form__input-group">
                <input type="text" name="daftarUsername" id="signupUsername" class="form__input" placeholder="Username" />
                <div class="form__input-error-message"></div>
            </div>

            <div class="form__input-group">
                <input type="email" name="daftarEmail" id="signupEmail" class="form__input" placeholder="Email Address" />
                <div class="form__input-error-message"></div>
            </div>

            <div class="form__input-group">
                <input type="password" name="daftarPasswd" id="signupPasswd" class="form__input" placeholder="Password"  />
                <div class="form__input-error-message"></div>
            </div>

            <div class="form__input-group">
                <input type="password" name="daftarCPasswd" id="signupCPasswd" class="form__input" placeholder="Confirm Password"  />
                <div class="form__input-error-message"></div>
            </div>
            
            <button class="form__button" type="submit">Daftar</button>
            
            <p class="form__text">
                <a href="#" id="linkLogin" class="form__link">Sudah punya akun? Sign in disini!</a>
            </p>
        </form>
    </div>
    <script src="js/main.js">
    //     var fs = require('fs');
    //     var data = fs.readFileSync('main.json');
    //     var main =  JSON.parse(data);
    //     const express = require('express');
    //     const app = express();
    //     const PORT = 3000;
    //     app.listen(PORT, () => console.log('listening...'));
    //     app.use(express.static('website'));
    //     function niuser() {
    //         newUser = {
    //             username: document.getElementById('signupUsername').value,
    //             password: document.getElementById('signupPasswd').value,
    //             email: document.getElementById('signupEmail').value,
    //         };
    //         return newUser;
    //     }
       
    //     const fs = require('fs');
    //     const saveData = (newUser) => {
    //         const finished = (error) => {
    //             if (error) {
    //                 console.error(error);
    //                 return;
    //             }
    //         }
    //         const jsonData = JSON.stringify(newUser);
    //         fs.writeFile('main.json', jsonData, finished)
    //     }
    //     saveData(newUser);
    // document.getElementById('daftar').innerHTML = '<p>${niuser}</p>'
    </script>

</body>
</html>
<?php /**PATH C:\documents\applications\ippl-app\resources\views/login.blade.php ENDPATH**/ ?>