
<?php $__env->startSection('container'); ?>
    <h1>Aye Imma go Sleep</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/dashboard/index.blade.php ENDPATH**/ ?>