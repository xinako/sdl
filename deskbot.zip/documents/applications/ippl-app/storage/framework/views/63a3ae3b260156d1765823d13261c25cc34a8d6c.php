

<?php $__env->startSection('container'); ?>
<link rel="stylesheet" href="css/main.css">
<div class="bodeh">
    
    
        <form class="form" id="login" action="/login" method="POST">
            <?php echo csrf_field(); ?>
            <h1 class="form__title">Login</h1>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert" style="color: rgb(42, 225, 42)">
                    <center><?php echo e(session('success')); ?></center>
                </div>
            <?php endif; ?>
            <?php if(session()->has('loginError')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert" style="color: rgb(209, 25, 25)">
                <center><?php echo e(session('loginError')); ?></center>
            </div>
            <?php endif; ?>
            <div class="form__message form__input--error"></div>
            
            <div class="form__input-group">
                <input type="text" name="username" id="loginUsr" class="form__input" placeholder="Username" required value="<?php echo e(old('username')); ?>" autofocus/>
            </div>
          
            <div class="form__input-group">
                <input type="password" name="password" id="loginPass" class="form__input" placeholder="Password"  required/>
                <?php $__errorArgs = ['password','username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form__input-error-message">Username atau Password salah</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class="form__button" href="" type="submit">Login</button>
            
            
            
            <p class="form__text">
                <a href="/register" id="linkCreateAccount" class="form__link">Tidak punya akun? Buat akun disini!</a>
            </p>
            <p class="form__text">
                <a href="/loginmitra" id="linkCreateAccount" class="form__link">Login sebagai Mitra</a>
            </p>
        </form>
    
</div>
    <script src="js/login.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\documents\applications\ippl-app\resources\views/login/index.blade.php ENDPATH**/ ?>