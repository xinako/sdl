    
<!-- header section starts      -->

<header>

    <a href="#" class="logo"><i class="fas fa-utensils"></i>kedai.</a>

    <nav class="navbar">
        <a class="active" href="#home">home</a>
        <a class="active" href="#dishes">dishes</a>
        <a class="active" href="#about">about</a>
        <a class="active" href="#dis">menu</a>
        <a href="#review">review</a>
        <a class="active" href="#order">order</a>
        <a href="#login">login</a>
    </nav>

    <div class="icons">
        <i class="fas fa-bars" id="menu-bars"></i>
        <i class="fas fa-search" id="search-icon"></i>
        <a href="#dishes" class="fas fa-heart"></a>
        <a href="#order" class="fas fa-shopping-cart"></a>
    </div>

</header>

<!-- header section ends-->

<!-- search form  -->

<form action="" id="search-form">
    <input type="search" placeholder="search here..." name="" id="search-box">
    <label for="search-box" class="fas fa-search"></label>
    <i class="fas fa-times" id="close"></i>
</form>
<?php /**PATH C:\documents\applications\ippl-app\resources\views/navbar/navbar.blade.php ENDPATH**/ ?>