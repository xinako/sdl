  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="/home"><img src="img/hellocat.png" alt="" class="img-fluid"></a>
        
        
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="/home#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="/home#about">About Us</a></li>
          
          <li><a class="nav-link scrollto" href="/home#portfolio">Veteriners</a></li>
          
          
          <li><a class="nav-link scrollto" href="/home#contact">Contact</a></li>
          <?php if(auth()->guard()->check()): ?>
          <li><a class="getstarted scrollto" href="/profile"><?php echo e(auth()->user()->username); ?></a></li>
          
          <?php else: ?>
          <li><a class="getstarted scrollto" href="/login">Login</a></li>
          <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
<?php /**PATH C:\documents\applications\ippl-app\resources\views/partials/navbar.blade.php ENDPATH**/ ?>