<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\ProductController;
// use Illuminate\Auth\Middleware\Authenticate as Middleware;
// use Illuminate\Support\Facades\Auth;
// use App\Http\Controllers\CartController;
// use App\Http\Controllers\ProductController;
// use App\Http\Controllers\Auth\LoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/home', function () {
    return view('hellocat', [
        "title" => "HelloCat | Home",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/homemitra', function () {
    return view('hellocat2', [
        "title" => "HelloCat | Home Mitra",
        "webcss" => "css/Menu(1).css"
    ]);
});


// Route::get('/menu', function () {
//     return view('dis', [
//         "title" => "Kedai GF | Menu",
//         "webcss" => "css/discss.css"
//     ]);
// });

// Route::get('user', [LoginController::class, 'index']);
// Route::post('user/create',[Usercontrol::class, 'store']);
// Route::get('/login', function () {
//     return view('login', [
//         "title" => "Kedai GF | Login",
//         "webcss" => "css/Menu(1).css"
//     ]);
// });

Route::get('/login', [LoginController::class, 'index'])->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout']);
Route::get('/register', [RegisterController::class, 'index']);
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/loginmitra', [LoginController::class, 'index2'])->middleware('guest');
Route::post('/loginmitra', [LoginController::class, 'authenticate2']);
Route::post('/logoutmitra', [LoginController::class, 'logout2']);
Route::get('/registermitra', [RegisterController::class, 'index2']);
Route::post('/registermitra', [RegisterController::class, 'store']);


Route::get('/profile', function () {
    return view('login.profile', [
        "title" => "HelloCat | Profile",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/profilemitra', function () {
    return view('login.profile2', [
        "title" => "HelloCat | Profile Mitra",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/consultdaring', function () {
    return view('online', [
        "title" => "HelloCat | Consult Daring",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/consultluring', function () {
    return view('offline', [
        "title" => "HelloCat | Consult Luring",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/minigames', function () {
    return view('game', [
        "title" => "HelloCat | Mini Games",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/chat', function () {
    return view('chat', [
        "title" => "HelloCat | Chat",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/schedule', function () {
    return view('schedule', [
        "title" => "HelloCat | Checkout",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/checkout', function () {
    return view('checkout', [
        "title" => "HelloCat | Checkout",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/details', function () {
    return view('details', [
        "title" => "HelloCat | Details",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/datalist', function () {
    return view('doctor.datalist', [
        "title" => "HelloCat | User Data",
        "webcss" => "css/Menu(1).css"
    ]);
});

// Route::get('/historylist', function () {
//     return view('doctor.historylist', [
//         "title" => "HelloCat | History",
//         "webcss" => "css/Menu(1).css"
//     ]);
// });

Route::get('/booklist', function () {
    return view('doctor.booklist', [
        "title" => "HelloCat | Booking List",
        "webcss" => "css/Menu(1).css"
    ]);
});

Route::get('/dashboard', [DashboardController::class, 'index']);
Route::get('/menu', [ProductController::class, 'productList'])->name('products.list');
Route::get('/cart', [CartController::class, 'cartList'])->name('cart.list');
Route::post('/menu', [CartController::class, 'addToCart'])->name('cart.store');
// Route::post('/update-cart', [CartController::class, 'updateCart'])->name('cart.update');
// Route::post('/remove', [CartController::class, 'removeCart'])->name('cart.remove');
// Route::post('/clear', [CartController::class, 'clearAllCart'])->name('cart.clear');
// Route::post('/cart', [CartController::class, 'finishCart'])->name('cart.finish');

