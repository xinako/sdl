@extends('layout.main')
@section('container')
<style>
    .home {
        font-size: 1rem;
        font-weight: 400;
        line-height: 1;
        color: #030100;
        text-align: left;
        margin-top: 15%;
        margin-left: 25%;
    }
    .menuses {
        border-radius: 4px;
        box-shadow: 0 3px 6px #0000001c;
        background-color: #fff;
        padding: 15px 15px 11px;
        margin: 10px 16px 10px 0;
        position: relative;
        width: 120px;
        height: 185px;
        display: flex;
        flex-direction: column;
        align-items: center;
        outline: none;
        cursor: pointer;
        color: black;
    }

    .menus {
        display: flex;
        flex-direction: row;
        margin-top: 27px;
    }
</style>
<section class="home">
    <div class="content" style="color: black;">
        <div class="menus" style="">
            <a class="menuses" href="/schedule"><img src="img/hewani.jpg" alt="Consult Online With Veteriner"width="80" height="80" style="border-radius: 5px;"><p>Drh. Sayekti</p><center>Rp. 200.000</center></a>
            
        </div> 
    </div>
</section>
{{-- <link rel="stylesheet" href="css/calendar.css">
<div class="calendar">
    <div class="calendar__picture">
      <h2>18, Sunday</h2>
      <h3>November</h3>
    </div>
    <div class="calendar__date">
      <div class="calendar__day">M</div>
      <div class="calendar__day">T</div>
      <div class="calendar__day">W</div>
      <div class="calendar__day">T</div>
      <div class="calendar__day">F</div>
      <div class="calendar__day">S</div>
      <div class="calendar__day">S</div>
      <div class="calendar__number"></div>
      <div class="calendar__number"></div>
      <div class="calendar__number"></div>
      <div class="calendar__number">1</div>
      <div class="calendar__number">2</div>
      <div class="calendar__number">3</div>
      <div class="calendar__number">4</div>
      <div class="calendar__number">5</div>
      <div class="calendar__number">6</div>
      <div class="calendar__number">7</div>
      <div class="calendar__number">8</div>
      <div class="calendar__number">9</div>
      <div class="calendar__number">10</div>
      <div class="calendar__number">11</div>
      <div class="calendar__number">12</div>
      <div class="calendar__number">13</div>
      <div class="calendar__number">14</div>
      <div class="calendar__number">15</div>
      <div class="calendar__number">16</div>
      <div class="calendar__number">17</div>
      <div class="calendar__number calendar__number--current">18</div>
      <div class="calendar__number">19</div>
      <div class="calendar__number">20</div>
      <div class="calendar__number">21</div>
      <div class="calendar__number">22</div>
      <div class="calendar__number">23</div>
      <div class="calendar__number">24</div>
      <div class="calendar__number">25</div>
      <div class="calendar__number">26</div>
      <div class="calendar__number">27</div>
      <div class="calendar__number">28</div>
      <div class="calendar__number">29</div>
      <div class="calendar__number">30</div>
    </div>
  </div> --}}
@endsection