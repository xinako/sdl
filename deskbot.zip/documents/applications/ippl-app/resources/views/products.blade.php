@extends('layout.frontend')

@section('content')
    <div class="container px-6 mx-auto">
        <h3 class="text-2xl font-medium text-gray-700">Product List</h3>
        <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
            
                @foreach ($products as $product)
                    @if($product->kategori == 'Food')
                    <div class="box">
                        <div class="image">
                            <img src="{{ url($product->image) }}" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3>{{ $product->kategori }}</h3>
                            <p>{{ $product->name }}</p>
                            <form action="{{ route('cart.store') }}" method="POST" enctype="multipart/form-data" class="btn">
                                @csrf
                                <input type="hidden" value="{{ $product->id }}" name="id">
                                <input type="hidden" value="{{ $product->kategori }}" name="kategori">
                                <input type="hidden" value="{{ $product->name }}" name="name">
                                <input type="hidden" value="{{ $product->price }}" name="price">
                                <input type="hidden" value="{{ $product->image }}"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.{{ $product->price }}</span>
                        </div>
                    </div>
                    @endif
                @endforeach
                </div>
            </section> 
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
    
                @foreach ($products as $product)
                @if($product->kategori == 'Fastfood')
                    <div class="box">
                        <div class="image">
                            <img src="{{ url($product->image) }}" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3>{{ $product->kategori }}</h3>
                            <p>{{ $product->name }}</p>
                            <form action="{{ route('cart.store') }}" method="POST" enctype="multipart/form-data" class="btn">
                                @csrf
                                <input type="hidden" value="{{ $product->id }}" name="id">
                                <input type="hidden" value="{{ $product->kategori }}" name="kategori">
                                <input type="hidden" value="{{ $product->name }}" name="name">
                                <input type="hidden" value="{{ $product->price }}" name="price">
                                <input type="hidden" value="{{ $product->image }}"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.{{ $product->price }}</span>
                        </div>
                    </div>
                    @endif
                @endforeach
                </div>
            </section> 
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
    
                @foreach ($products as $product)
                @if($product->kategori == 'Snack')
                    <div class="box">
                        <div class="image">
                            <img src="{{ url($product->image) }}" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3>{{ $product->kategori }}</h3>
                            <p>{{ $product->name }}</p>
                            <form action="{{ route('cart.store') }}" method="POST" enctype="multipart/form-data" class="btn">
                                @csrf
                                <input type="hidden" value="{{ $product->id }}" name="id">
                                <input type="hidden" value="{{ $product->kategori }}" name="kategori">
                                <input type="hidden" value="{{ $product->name }}" name="name">
                                <input type="hidden" value="{{ $product->price }}" name="price">
                                <input type="hidden" value="{{ $product->image }}"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.{{ $product->price }}</span>
                        </div>
                    </div>
                    @endif
                @endforeach
                </div>
            </section> 
            <section class="menu" id="menu">

                <h3 class="sub-heading"> Menu Makanan Berat</h3>
                <h1 class="heading"> Mau pilih yang mana ?</h1>
            
                <div class="box-container">
    
                @foreach ($products as $product)
                @if($product->kategori == 'choco')
                    <div class="box">
                        <div class="image">
                            <img src="{{ url($product->image) }}" alt="">
                            <a href="#" class="fas fa-heart"></a>
                        </div>
                        <div class="content">
                            <div class="stars">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                            </div>
                            <h3>{{ $product->kategori }}</h3>
                            <p>{{ $product->name }}</p>
                            <form action="{{ route('cart.store') }}" method="POST" enctype="multipart/form-data" class="btn">
                                @csrf
                                <input type="hidden" value="{{ $product->id }}" name="id">
                                <input type="hidden" value="{{ $product->kategori }}" name="kategori">
                                <input type="hidden" value="{{ $product->name }}" name="name">
                                <input type="hidden" value="{{ $product->price }}" name="price">
                                <input type="hidden" value="{{ $product->image }}"  name="image">
                                <input type="hidden" value="1" name="quantity">
                                <button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>
                            </form>
                            <span class="price">Rp.{{ $product->price }}</span>
                        </div>
                    </div>
                    @endif
                @endforeach
                </div>
            </section> 
        </div>
    </div>
@endsection