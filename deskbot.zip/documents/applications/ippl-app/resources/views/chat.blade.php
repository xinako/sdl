@extends('layout.main')
@section('container')
<script src="https://apps.elfsight.com/p/platform.js" defer></script>
<center><div class="elfsight-app-17580849-45cf-4e6e-8cba-0ec8f5670087" style="margin-top: 5rem"></div></center>
{{-- <link rel="stylesheet" href="css/chat.css">
<style>
    .futer {
        text-align: center;
        /* padding: 3px; */
        position: fixed;
        bottom: 0;
        /* left: 5vh; */
        /* right: 0; */
        margin-left: 5rem;
    }

    .meseg {
        width: 80vw;  
        border-radius: 7.5px; 
        box-shadow: none;
        height: 2rem;
        padding-left: 1rem;
        border: 1px solid black;;
    }
    .send {
        float: right;
    }
</style>
<div class="babo" style="margin-top: 10vh">
    <div class="bubbleWrapper" style="font-size: 15px">
        <div class="inlineContainer">
            <img class="inlineIcon" src="https://cdn1.iconfinder.com/data/icons/ninja-things-1/1772/ninja-simple-512.png">
            <div class="otherBubble other">
                Hallo ada yang bisa saya bantu?
            </div>
        </div><span class="other">08:41</span>
    </div>
    <div class="bubbleWrapper" style="font-size: 15px">
        <div class="inlineContainer own">
            <img class="inlineIcon" src="https://www.pinclipart.com/picdir/middle/205-2059398_blinkk-en-mac-app-store-ninja-icon-transparent.png">
            <div class="ownBubble own">
            Iya dok, ini kucing saya sakit-sakitan, nggak mau makan sama minum sudah 5 hari. Ini Gimana ya dok?!
            </div>
        </div><span class="own">08:55</span>
    </div>
    <div class="bubbleWrapper" style="font-size: 15px">
        <div class="inlineContainer">
            <img class="inlineIcon" src="https://cdn1.iconfinder.com/data/icons/ninja-things-1/1772/ninja-simple-512.png">
            <div class="otherBubble other">
                Baik ibu, apakah kucing ibu sudah di berikan obat cacing sebelumnya?
            </div>
        </div>
    </div><span class="other">10:13</span>
    <div class="bubbleWrapper" style="font-size: 15px">
        <div class="inlineContainer own">
            <img class="inlineIcon" src="https://www.pinclipart.com/picdir/middle/205-2059398_blinkk-en-mac-app-store-ninja-icon-transparent.png">
            <div class="ownBubble own">
            Belum dok, dimana ya bisa beli obat cacing itu?
            </div>
        </div><span class="own">11:07</span>
    </div>
    <div class="bubbleWrapper" style="font-size: 15px">
        <div class="inlineContainer">
            <img class="inlineIcon" src="https://cdn1.iconfinder.com/data/icons/ninja-things-1/1772/ninja-simple-512.png">
            <div class="otherBubble other">
                Bisa beli di petshop terdekat ya ibu, diberikan setiap 6 bulan sekali dan jangan sampai kucingnya stress ya.
            </div>
        </div><span class="other">11:11</span>
    </div>
    <footer class="futer">
        <input class="meseg" type="text" placeholder="Text">
        <a class="send" href="#"><img src="img/message.png" alt=""width="50" height="25"></a>
    </footer>
</div> --}}
@endsection