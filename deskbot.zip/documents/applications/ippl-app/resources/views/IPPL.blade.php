@extends('layout.main')
@section('container')
<!-- home section starts  -->
<section class="home" id="home" style="
text-transform: capitalize;">

    <div class="content">
        <h3>Selamat Datang di Kedai GF</h3>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat labore, sint cupiditate distinctio tempora reiciendis.</p>
        <a href="dis.html" class="btn">pesan sekarang</a>
    </div>

</section>
<!-- home section ends-->

<!-- dishes section start-->
<section class="dishes" id="dishes" style="
text-transform: capitalize;">
@if(session()->has('success'))
<script>alert("Pesananmu telah masuk!");</script>
@endif
    <h3 class="sub-heading"> our dishes </h3>
    <h1 class="heading"> popular dishes </h1>

    <div class="box-container">

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/batagorayam.png" alt="">
            <p>Batagor Ayam</P>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>18k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/bakso.png" alt="">
            <p>Bakso</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>15k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/empek.png" alt="">
            <p>Empek - Empek</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>10k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/kopi.png" alt="">
            <p> Capucino Coffee</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>7k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/miekuah.png" alt="">
            <p> Mie Goreng/Kuah Spesial</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>15k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/lumpiabakso.png" alt="">
            <p>Lumpia Bakso</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>15k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/matcha.png" alt="">
            <p>Matcha Tea</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>10k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

        <div class="box">
            <a href="#" class="fas fa-heart"></a>
            <a href="#" class="fas fa-eye"></a>
            <img src="img/thaitea.png" alt="">
            <p>Thai Milk Tea</p>
            <h3>tasty food</h3>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <span>13k</span>
            <a href="#" class="btn">keranjang</a>
        </div>

    </div>

</section>
<!-- dishes section ends-->
<!-- about section stars-->
<section class="about" id="about">

    <h3 class="sub-heading"> About Us </h3>
    <h1 class="heading"> why choose us? </h1>

    <div class="row">

        <div class="image">
            <img src="img/kedaigf.png" alt="">
        </div>

        <div class="content">
            <h3>Kedai GF</h3>
            <p>Kedai GF terletak di kota Tenggarong Kutai Kartanegara, yang lebih tepatnya berada di desa loa lepu. 
            Memiliki view pemandangan yang memanjakan mata menjadi daya jual tersendiri kepada pelanggan yang berkunjung.</p>
            <p>Kedai GF menyajikan berbagai jenis makanan dan minuman dengan harga terjangkau. Kedai GF juga menyajikan tempat rooftop yang memiliki pemandangan yang indah </p>
            <div class="icons-container" style="
            text-transform: capitalize;">
                <div class="icons">
                    <i class="fas fa-shipping-fast"></i>
                    <span>free delivery</span>
                </div>
                <div class="icons">
                    <i class="fas fa-dollar-sign"></i>
                    <span>easy payments</span>
                </div>
                <div class="icons">
                    <i class="fas fa-headset"></i>
                    <span>24/7 service</span>
                </div>
            </div>
            <a href="#" class="btn">Pesan Sekarang</a>
        </div>

    </div>

</section>
<!-- about section ends-->

<!-- order section stars-->
<section class="order" id="order" style="
text-transform: capitalize;">

    <h3 class="sub-heading"> pesan sekarang </h3>
    <h1 class="heading"> free and fast </h1>

    <form action="">

        <div class="inputBox">
            <div class="input">
                <span>nama kamu</span>
                <input type="text" placeholder="masukan nama kamu">
            </div>
            <div class="input">
                <span>nomor meja</span>
                <input type="number" placeholder="masukan nomor meja kamu">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
                <span>snack pesanan kamu</span>
                <input type="text" placeholder="masukan nama makanan pesanan kamu">
            </div>
            <div class="input">
                <span>toping tambahan snack </span>
                <input type="test" placeholder="masukan toping tambahan untuk snack ">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
                <span>Minuman pesanan kamu</span>
                <input type="text" placeholder="masukan nama minuman pesanan kamu">
            </div>
            <div class="input">
                <span>toping tambahan minuman</span>
                <input type="test" placeholder="masukan toping tambahan untuk minuman ">
            </div>
            <div class="input">
                <span>makanan pesananan kamu</span>
                <input type="test" placeholder="masukan toping tambahan untuk minuman ">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
                <span>date and time</span>
                <input type="datetime-local">
            </div>
        </div>
        <div class="inputBox">
            <div class="input">
                <span>Catatan</span>
                <textarea name="" placeholder="enter your message" id="" cols="30" rows="10"></textarea>
            </div>
        </div>

        <input type="submit" value="order now" class="btn">

    </form>

</section>
@endsection
