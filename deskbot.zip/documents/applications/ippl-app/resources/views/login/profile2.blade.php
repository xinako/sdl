@extends('layout.main2')
@section('container')
<style>
    .home {
        font-size: 1rem;
        font-weight: 400;
        line-height: 1;
        color: #030100;
        text-align: left;
        margin-top: 15%;
        margin-left: 25%;
    }
    .logout {
        border-radius: 5px;
        box-shadow: 0 0px 10px #0000001c;
        background-color: #fff;
        padding: 55px 0px 0px;
        margin: 10px 16px 10px 0;
        position: relative;
        width: 114px;
        height: 136px;
        display: flex;
        flex-direction: column;
        align-items: center;
        outline: none;
        cursor: pointer;
        color: black;
        border: 1px solid black;
    }

    .menus {
        display: flex;
        flex-direction: row;
        margin-top: 27px;
    }
</style>
<section class="home">
    <form action="/logoutmitra" method="POST">
        @csrf
    <button type="submit" class="logout">Logout</button>
    </form>
</section>
<section>
    
</section>
@endsection