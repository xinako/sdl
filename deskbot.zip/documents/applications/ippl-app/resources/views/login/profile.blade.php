@extends('layout.main')
@section('container')
{{-- <style>
    .home {
        font-size: 1rem;
        font-weight: 400;
        line-height: 1;
        color: #030100;
        text-align: left;
        margin-top: 15%;
        margin-left: 25%;
        float: left;
        
    }
    .menuses {
        border-radius: 5px;
        box-shadow: 0 0px 10px #0000001c;
        background-color: #fff;
        padding: 35px 0px 0px;
        margin: 10px 16px 10px 0;
        position: relative;
        width: 250px;
        height: 50px;
        display: flex;
        flex-direction: column;
        align-items: center;
        outline: none;
        cursor: pointer;
        color: black;
        border: 1px solid black;
    }

    .logout {
        border-radius: 5px;
        box-shadow: 0 0px 10px #0000001c;
        background-color: #fff;
        padding: 35px 0px 0px;
        margin: 10px 16px 10px 0;
        position: relative;
        width: 250px;
        height: 50px;
        display: flex;
        flex-direction: column;
        align-items: center;
        outline: none;
        cursor: pointer;
        color: black;
        border: 1px solid black;
    }
    .menus {
        display: flex;
        flex-direction: row;
        margin-top: 27px;
    }
</style> --}}
    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
        <div class="container">
  
          <div class="d-flex justify-content-between align-items-center">
            <h2>Profile</h2>
            <ol>
              <li><a href="index.html">Home</a></li>
              <li>Test</li>
              {{-- <li><p class="menuses">{{ auth()->user()->username }}</p></li>
              <li><p class="menuses">{{ auth()->user()->email }}</p></li>
              <form action="/logout" method="POST">
                @csrf
                <li><button type="submit" class="logoutx">Logout</button></li>
            </form> --}}
            </ol>
          </div>
  
        </div>
      </section><!-- End Breadcrumbs Section -->
  
      <section class="inner-page">
        <div class="container">
          <p>
            <ul><p class="menuses">Name : {{ auth()->user()->username }}</p></ul>
              <ul><p class="menuses">Email : {{ auth()->user()->email }}</p></ul>
              <form action="/logout" method="POST">
                @csrf
                <ul><button type="submit" class="logoutx">Logout</button></ul>
            </form>
          </p>
        </div>
      </section>
  
    </main><!-- End #main -->

</section>
@endsection