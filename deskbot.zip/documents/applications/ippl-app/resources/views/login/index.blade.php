{{-- <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="{{ $stylecss }}" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <title>{{ $title }}</title>
</head>
<body>
     --}}
@extends('layout.main')
@section('container')
<link rel="stylesheet" href="css/main.css">
<div class="bodeh">
    {{-- <div class="container"> --}}
    
        <form class="form" id="login" action="/login" method="POST">
            @csrf
            <h1 class="form__title">Login</h1>
            @if(session()->has('success'))
                <div class="alert alert-warning alert-dismissible fade show" role="alert" style="color: rgb(42, 225, 42)">
                    <center>{{ session('success') }}</center>
                </div>
            @endif
            @if(session()->has('loginError'))
            <div class="alert alert-warning alert-dismissible fade show" role="alert" style="color: rgb(209, 25, 25)">
                <center>{{ session('loginError') }}</center>
            </div>
            @endif
            <div class="form__message form__input--error"></div>
            
            <div class="form__input-group">
                <input type="text" name="username" id="loginUsr" class="form__input" placeholder="Username" required value="{{ old('username') }}" autofocus/>
            </div>
          
            <div class="form__input-group">
                <input type="password" name="password" id="loginPass" class="form__input" placeholder="Password"  required/>
                @error('password','username')
                <div class="form__input-error-message">Username atau Password salah</div>
                @enderror
            </div>

            <button class="form__button" href="" type="submit">Login</button>
            
            {{-- <p class="form__text">
                <a href="#" class="form__link">Lupa Password?</a>
            </p> --}}
            
            <p class="form__text">
                <a href="/register" id="linkCreateAccount" class="form__link">Tidak punya akun? Buat akun disini!</a>
            </p>
            <p class="form__text">
                <a href="/loginmitra" id="linkCreateAccount" class="form__link">Login sebagai Mitra</a>
            </p>
        </form>
    {{-- </div> --}}
</div>
    <script src="js/login.js"></script>
@endsection
