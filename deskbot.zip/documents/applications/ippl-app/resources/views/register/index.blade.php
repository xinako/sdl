@extends('layout.main')
@section('container')
<link rel="stylesheet" href="css/main.css">
    <div class="bodih">
        <form class="form" id="CreateAccount" method="POST" action="/register">
            @csrf
            <h1 class="form__title">Buat Akun User</h1>
            <div class="form__message form__input--error"></div>

            <div class="form__input-group">
                <input type="text" name="username" id="signupUsername" class="form__input" placeholder="Username" required value="{{ old('username') }}"/>
                <div class="form__input-error-message"></div>
                
            </div>

            <div class="form__input-group">
                <input type="email" name="email" id="signupEmail" class="form__input" placeholder="Email Address" required value="{{ old('email') }}"/>
                <div class="form__input-error-message"></div>
   
            </div>

            <div class="form__input-group">
                <input type="password" name="password" id="signupPasswd" class="form__input" placeholder="Password"  required/>
                <div class="form__input-error-message"></div>
                
            </div>

            <div class="form__input-group">
                <input type="password" name="cpassword" id="signupCPasswd" class="form__input" placeholder="Confirm Password" required/>
                <div class="form__input-error-message"></div>
                @error('cpassword')
                <div class="form__input-error-message">Mohon mengisi Form dengan Benar!</div>
                @enderror
            </div>
            
            <button class="form__button" type="submit">Daftar</button>
            
            <p class="form__text">
                <a href="/login" id="linkLogin" class="form__link">Sudah punya akun? Sign in disini!</a>
            </p>
        </form>
    </div>
    <script src="js/register.js"></script>
@endsection   
