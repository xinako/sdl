@extends('layout.main')
@section('container')
<!-- food -->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Makanan Berat</h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="img/menu-1 (2).jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>food</h3>
                <p> Bakso </p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">15000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-2.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>food</h3>
                <p>Mie Goreng / Kuah Original.</p>
                <a href="#" class="btn">add to cart</a>
                <span class="price">8000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-3.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>food</h3>
                <p>Mie Goreng / Kuah Spesial.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">12000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-4.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>food</h3>
                <p>Ayam Lalapan/Gepuk.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">12000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-5.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>food</h3>
                <p>Ayam Lapapan/Gepuk + Nasi.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">15000</span>
            </div>
        </div>
    </div>
</section>

<!-- Fastfood start-->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Fastfood</h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="img/menu-6.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Nugget Goreng</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-7.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Kentang Goreng OR</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-8.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Kentang Goreng Premium.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">15000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-9.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Sosis Goreng.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">15000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-10.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Beef Burger OR.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">12000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu11.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Burger Nugget.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">14000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-12.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Beef Burger Patties.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">15000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-13.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>fastfood</h3>
                <p>Sosis + Kentang goreng.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">15000</span>
            </div>
        </div>
    </div>
</section>
<!-- Fastfood ends-->

<!-- Snack stars-->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Snack</h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="img/menu-15.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snack</h3>
                <p>Donat Krispi</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">8000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-16.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Pisang Naget.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">8000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-18.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Pisang Cocol.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">8000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-17.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Roti Bakar.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-19.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Cimol Keju.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-20.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Lumpia Bakso.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-21.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Empek - Empek.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/menu-22.jpg" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Tahu Bakso.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/batagorayam.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Batagor Ayam.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">10000</span>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="img/batagorayam.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>snackfood</h3>
                <p>Batagor Ayam.</p>
                <a href="#" class="btn">keranjang</a>
                <span class="price">18000</span>
            </div>
        </div>
    </div>
</section>

<!-- snack ends-->

<!-- Drink stars-->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Choco </h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="drink/choco.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Black Milo</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/bengbeng.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Coklat Beng Beng.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/aren.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Coklat Gula Aren.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>
        
        
        <div class="box">
            <div class="image">
                <img src="drink/caramel.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Choco Caramel.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>
        
        <div class="box">
            <div class="image">
                <img src="drink/cheese.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Choco Cheese.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/hazelnut.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Choco Hazelnut.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/malt.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Choco Malt.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/choco.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Choco Milo.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/oreo.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Choco Oreo.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/darkcok.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Dark Chocolate.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="drink/velvet.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Choco</h3>
                <p>Red Velvet.</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        
    </div>
</section>

<!-- Cofee stars-->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Coffee </h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="cofee/caramel.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Caramel Machiato</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/capucino.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Capucino</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/beng.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Coffee Beng Beng</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/aren.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Kopi Susu Gula Aren</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/mocacino.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Mocaccino</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/tiramisu.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Tiramisu</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/vietnam.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Vietnam Coffee</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="cofee/latev.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Coffee</h3>
                <p>Vanilla Latte</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>
    </div>
</section>

<!-- Cofee ends-->

<!-- Tea stars-->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Tea </h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="tea/green.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Tea</h3>
                <p>Green Tea</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="tea/lateg.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Tea</h3>
                <p>Green Tea Latte</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="tea/matcha.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Tea</h3>
                <p>Matcha</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="tea/tmtea.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Tea</h3>
                <p>Thai Milk Tea</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="tea/ttea.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Tea</h3>
                <p>Thai Tea</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

    </div>
</section>

<!-- Tea ends-->

<!-- Fruit stars-->
<section class="menu" id="menu">

    <h3 class="sub-heading"> Menu Fruit </h3>
    <h1 class="heading"> Mau pilih yang mana ?</h1>

    <div class="box-container">

        <div class="box">
            <div class="image">
                <img src="fruit/avocado.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Fruit</h3>
                <p>Avocado</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        <div class="box">
            <div class="image">
                <img src="fruit/bubble.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Fruit</h3>
                <p>Bubble Gum</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>
        
        <div class="box">
            <div class="image">
                <img src="fruit/taro.png" alt="">
                <a href="#" class="fas fa-heart"></a>
            </div>
            <div class="content">
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>
                <h3>Fruit</h3>
                <p>Taro</p>
                <p>Original/Hangat/Medium/Jumbo</p>
                <span class="price">3000/7000/8000/13000</span>
                <a href="#" class="btn">keranjang</a>
            </div>
        </div>

        

    </div>
</section>
@endsection