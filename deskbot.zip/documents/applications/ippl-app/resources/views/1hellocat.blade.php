@extends('layout.main')
@section('container')
<!-- home section starts  -->
<style>
    .home {
        font-size: 1rem;
        font-weight: 400;
        line-height: 1;
        color: #030100;
        text-align: left;
        margin-top: 15%;
        margin-left: 32.5%;
    }
    .menuses {
        border-radius: 4px;
        box-shadow: 0 3px 6px #0000001c;
        background-color: #fff;
        padding: 15px 15px 11px;
        margin: 10px 16px 10px 0;
        position: relative;
        width: 114px;
        height: 136px;
        display: flex;
        flex-direction: column;
        align-items: center;
        outline: none;
        cursor: pointer;
        color: black;
    }

    .menus {
        display: flex;
        flex-direction: row;
        margin-top: 27px;
    }
</style>
<section class="home">
    
    <div class="content" style="
    color: black;">
        <div class="menus" style="">
            <a class="menuses" href="/consultdaring"><img src="img/doctor.png" alt="Consult Online With Veteriner"width="80" height="80"><p>Consult Online</p></a>
            <a class="menuses" href="/consultluring"><img src="img/book.png" alt="Book a Schedule for Veteriner"width="80" height="80"><p>Book Offline Meetings</p></a>
            {{-- <a class="menuses" href="/chat"><img src="img/chat.png" alt="Chat With Veteriners"width="80" height="80"><p>Chat With Veteriners</p></a> --}}
            <a class="menuses" href="/minigames"><img src="img/minigames.png" alt="Mini Games"width="80" height="80"><p>Mini Games</p></a>
        </div> 
    </div>
</section>
@endsection
